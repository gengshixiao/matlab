function [  ] = action()
%UNTITLED1 Summary of this function goes here
%  Detailed explanation goes here
 epsilon = 0.1;
r_comm=8.4;
r_lattice=7;
r_comm_sig= sig_norm_old(r_comm, epsilon);
r_lattice_sig = sig_norm_old(r_lattice, epsilon);
a=7;
b=7;
ha=0.2;
d=[0:0.1:(r_comm_sig+3)];
 for i=1:1:size(d,2);
   phia(1,i)=phi_a(d(1,i), r_comm_sig, r_lattice_sig, ha, a, b);
   %plot(d,phia);
 end
%phia=phi_a(d, r_comm_sig, r_lattice_sig, ha, a, b);
plot(d,phia)
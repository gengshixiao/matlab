function [out] = b_ik(q_i, qhat_ik, d_pie_sig, h, epsilon)
    out = rho_h( (sig_norm(q_i - qhat_ik, epsilon)/d_pie_sig), h);
    if out > 1 || out < 0
        'Error: adjacency matrix element out of range [0, 1]'
        out
    end
end
function [out] = sigma_1(z)
    out = ((z)/sqrt(1+z^2));
end
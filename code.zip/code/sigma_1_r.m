function [out] = sigma_1_r(z)
    out = zeros(1,size(z,1));
	for j=1:size(z,1)
	out(1,j) = ((z(1,j))/sqrt(1+z(1,j)^2));
	end
end
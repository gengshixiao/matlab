function [ out ] = flocking(framework, N, m, coord_min, coord_max, r_comm, r_lattice, r_safety, delta, tdiv, tmax, updates, plotControls, tswitch, time_varying, delay, constrain, quantization)
%Flocking and Consensus Problem Simulations ��Ⱥ�͹�ʶ����ģ��
%
%shaoshiliangswu@163.com
%Northeasten of University
%Department of Communication and information system ͨ������Ϣϵͳ��
%
%       framework:  selects which model (controls, discrete-time vs. 
%                   continuous time, etc.) to use��ܼܼ�ѡ�� �����ơ���ɢʱ��������ʱ��ȣ�
%                   0:
%                   1: 
%                   2:
%       N:          number of agents/nodes/flock-members (>=1) �ڵ�����
%       m:          number of dimensions (>=1) ά����
%       coord_min:  will be removed, set to 0
%       coord_max:  will be removed, set to 1000 for example
%       r_comm:     communications radius (try 8.4) �ڵ�֮���ͨ�ž���
%       r_lattice:  flocking/lattice/comfortable distance (try 7.0)  �ڵ�֮������ʾ���
%       
%       r_safety:   minimum distance to maintain safety (try 7.0)  �ڵ�֮�����С��ȫ����
%       
%       tdiv:       number of times to allow the system to evolve between 
%                   control cycle updates (>= 1; for example, =1 is one
%                   division per control cycle is the same as only looking 
%                   at control cycle) ����ϵͳ�ڿ���ѭ������֮���ݱ�Ĵ��� ��>=1�����磬=1 ÿ������ѭ����һ�������Ƿ�����鿴����ѭ����ͬ��
%       tmax:       time to run the system for (t_final)  ϵͳ����ʱ��
%                   frameworks 0, 1: try ~20
%                   framework 2: try >= 1000
%       updates:    number of times to update the plots (>=1)   number of times to update the plots(>=1)
%       plotControls:   if 1, plots all controls as functions of time  ���1�������пؼ�����Ϊʱ�亯��
%       tswitch:    used for multiple goals ���ڶ�Ŀ�����
%       time_varying: use time-varying parameters (if applicable to model)?
%       0 no, 1 yes  ʹ��ʱ����������������ģ�ͣ���0����1��
%       delay:      enable asynchronism? 0 synchronous, 1 asynchronous  �����첽��0ͬ����1�첽
%       constrain:  enable control (and state) saturation constraints? 0 
%                   allows infinite valued controls and states, 1 
%                   constrains/saturates controls and states  ���ÿ��ƣ���״̬������Լ����0��������ֵ�ؼ���״̬��1Լ��/���Ϳؼ���״̬

    %original sim:
    %d=7
    %r=1.2*d=8.4
    %d'=0.6*d=
    %r'=1.2*d'=
    %epsilon=0.1
    %a=b=5 for \phi
    %h=0.2 for \phi_a
    %h=0.9 for \phi_b
    %step size=0.01 to 0.03s (33hz-100hz)
    %N=150
    %initial positions \in gaussian with var=2500
    %initial velocities \in [-2, -1]^2 box
    
    %c1=1.75;
    %c2=25;
	flocking_suc_2_cnt = 0;
	
    c1gamma=0.1;% �ĳ�10.1 �ɺ��Ŷ���
    c2gamma=0.1;
    c1beta=10.25;
    c2beta=10.0;
    
    epsilon = 0.1;
    a=5;
    b=5;
    ha=0.2;
    hb=0.9;

    kappa = r_comm / r_lattice;
    r_flock = r_lattice; %synonym
    
    group_ic = 0;
    counter_ic = 0;
    quant_ic = 1;
    
    terminate = 0;
    terminate_rounds = 5; %number of rounds after termination to continue  ��ֹ��������е�����
	obstacles_flag = 0;

    if group_ic == 1
        N = N + 12 % we need 12 additional nodes to study each of the 4 combination cases ������Ҫ12������Ľڵ����о���4����ϰ����е�ÿһ��
    end
    
    QUANT_MODE_NONE = 0;
    QUANT_MODE_FLOOR = 1;
    QUANT_MODE_BETA = 2;
   
    %quantization constants  ��������
    if quantization == 0
        quant_mode = QUANT_MODE_NONE;
    else
        quantizer_precision = 4; %number of bits precision (# possible values)  λ�����ȣ�����ֵ��
        quant_mode = QUANT_MODE_BETA;
        quant_beta = ones(N,1)*delta/(4*(N-1)) %(1:N)'*delta/(4*(N-1)) this does not work
%         quant_beta = ones(N,1)*delta/4
%         if N > 5
%             %quant_beta(N-2) = delta/(3*(N-1))
%             quant_beta(N-1) = delta/(2*(N-1))
%         end
%         if N > 2
%             quant_beta(1) = delta/2
%             quant_beta(N) = delta/(2*(N-1))
%         end
%         quant_beta = ones(N,1)*(delta/(4));
    end
    
    if framework == 0
        system_type = 0; %0 continuous, 1 discrete-event system  0������1��ɢ�¼�ϵͳ
        numLyap = 0;
        leadNode = 1;
        
        Tc = 0.01;
        r_init = r_comm;

        v_max = 100;     %maximum velocity  ����ٶ�
        a_max = 1000;     %maximum acceleration  �����ٶ�
        %a_max = inf;
    end
    r_lattice_prime = 0.6 * r_lattice;
    r_comm_prime = 1.2 * r_lattice_prime;
    
    r_comm_sig    = sig_norm(r_comm, epsilon); %����ͨ�ŷ���
    r_lattice_sig = sig_norm(r_lattice, epsilon);%���㾧����
    r_safety_sig  = sig_norm(r_safety, epsilon); %���㰲ȫ���뷶��
    
    delay_min = - (Tc / 4);
    delay_max = (Tc / 4);

    %generate velocity matrix  �����ٶȾ���
    %p = ones(N, m); %start from 1 velocity  
    p = zeros(N, m)  %�ٶȴ�0��ʼ
	p_new = zeros(N,m);
    nodeType = zeros(N, m);
    
    %p = v_max + (-v_max - v_max).*rand(N, m)
    if constrain ~= 0
        p = sign(p).*(min(abs(p),v_max));
    end
    
    q=zeros(N, m);
    
    if framework == 0
        %generate state matrix randomly such that no nodes are already neighbors �������״̬����ʹ��û�нڵ��Ѿ����ھ�
        for i=1:1:N
            q(i,:) = coord_max + (coord_min - coord_max).*rand(1, m);

            for j=1:1:i %only need to go up to i's already initialized   ȷ�����нڵ�û���ھ�
                if i ~= j
                    %ensure no vertices start as neighbors, that is 
                    %(norm(q_i,q_j,2) < r) != true
                    %while size(neighborsSpatial(i, q(i,:), q, r_init, r_init),1) > 0
                    %   q(i,:) = coord_max + (coord_min - coord_max).*rand(1, m);
                    %end
                end
            end
        end
    end

    %q=[0:(r_lattice-delta):(r_lattice-delta)*(N-1)]';
    
    %q = [5; 50; 90; 120; 150; 180; 210; 230; 250; 260]
    %q = [1:N]'*r_init
    %q = [5; 5+r_safety+((r_init-r_safety)/2); 19; 26; 40; 47; 55; 62; 70; 77]
    %p = [v_max; -v_max; v_max; v_max; v_max; -v_max; v_max; -v_max; -v_max; v_max]
    %p = [v_max; -v_max; v_max; v_max; v_max; -v_max; v_max; -v_max; -v_max; v_max;
    %     v_max; -v_max; v_max; v_max; v_max; v_max; v_max: v_max: v_max; -v_max; -v_max; -v_max]
    %p = [v_max; -v_max];
    %v_max; v_max; v_max; v_max; v_max; v_max; -v_max; v_max; 
        %-v_max; v_max; v_max; v_max; v_max; v_max; v_max; v_max; v_max; -v_max]

    spatial_neighbors = zeros(N, N, N);

    tcyc=Tc;
    time_ctrl=[0:tcyc:tmax-tcyc]';      	%vector of control cycle times ����ѭ��ʱ��ʸ��
    time_traj=[0:tcyc/tdiv:tmax]';  		%vector of trajectories  ʸ���켣
    u_steps=round(((tmax-tcyc)/tcyc))+1;   	%number of control update steps  ���Ƹ��²�����
    steps=tmax/(tcyc/tdiv);         		%total numbers of trajectory steps  �켣������

    %goals for gamma control term
    qd=zeros(N, m);         %preallocate Ԥ����
    pd=zeros(N, m); 		%end with 0 velocity ��0�ٶȽ���
    
    %initial control value  ��ʼ����ֵ
    %u = (a_max + (-a_max - a_max).*rand(N, m));
    if framework ~= 2
        u = zeros(N, m);
    else
        u = q;
    end
    uGradient = zeros(N, m); %��ʼ���ݶ�
    uConsensus = zeros(N, m);%��ʼ��ͬĿ��
    uGamma = zeros(N, m);%��ʼGamma
    uBetaGradient = zeros(N, m);%��ʼ�����ݶ�
    uBetaConsensus = zeros(N, m);%��ʼ���¹�ͬĿ��
    uNew = zeros(N, m);
	uBeta = zeros(1, m);

%     %generate an equally spaced (by r_lattice) rectangular grid goal ���ɵȾࣨ��R_���񣩾�������Ŀ��
%     %TODO: generalize for m-dimensional (use cat and m-th root of N [need m loops?])
%     if m == 1
%         for i=1:N
%             qd(i,:) = ((i-1)*r_lattice) + coord_max;
%         end
%         %scatter(qd(:,1),zeros(N,1),[1:N]');
%     elseif m == 2
%         for i=1:ceil(sqrt(N))
%             for j=1:ceil(sqrt(N))
%                 qd((i-1)*ceil(sqrt(N))+j,:) = [((i-1)*r_lattice) ((j-1)*r_lattice)] + [coord_max coord_max];
%             end
%         end
%         %scatter(qd(:,1),qd(:,2));
%     elseif m == 3
%         for i=1:ceil(N^(1/3))
%             for j=1:ceil(N^(1/3))
%                 for k=1:ceil(N^(1/3))
%                     qd((i-1)*ceil(N^(2/3))+(j-1)*ceil(N^(1/3))+k,:) = [((i-1)*r_lattice) ((j-1)*r_lattice) ((k-1)*r_lattice)] + [coord_max coord_max coord_max];
%                 end
%             end
%         end
%         %scatter(qd(:,1),qd(:,2),qd(:,3));
%     end
%     qd=qd(1:N,:); %shrink to maximum N

    %qd=ones(N,m).*coord_max*(2+N);
    qd=ones(N,m).*coord_max;
    pd=ones(N,m).*(v_max/15);
	%qd=ones(N,1)*[200,50];
	%pd=ones(N,1)*[5,0];
    %pd=zeros(N,m)
    
    qr=qd;
    pr=pd;
    
    if framework ~= 2
        q_goal = qd;
    end
    
    %start at goal
    %q=qd;
    %p=pd;
    
    %obstacles: k obstacles with radius Rk, centered at yk �����ϰ����YKΪ���ģ��뾶ΪRK��K�ϰ���
    %Ms = [150 150; 30 100; 25 25]; %from paper, last row is radius, first rows are x,y,z,... positions
    %Ms = [100 110 120 130 150 160; 120 160 140 -20 140 0; 5 4 2 5 5 3]
	Ms = [100 110 120 130 150 160; 120 160 140 120 140 160; 5 4 2 5 5 3]
	%Ms = [100 110 120 130 150 160; 120 160 140 120 140 160; 5 4 2 5 5 3]
	%Ms = [200 210 220 230 250 260; 220 260 240 220 240 200; 5 4 2 5 5 3]
    R_k = Ms(size(Ms,1),:);
    for i=1:size(Ms,2)
        for j=1:size(Ms,1)-1
            y_k(i,j) = Ms(j,i);
        end
    end
    
    de = deviationEnergy(framework, q, q_goal, r_comm, r_lattice, delta) %�˺���Ӧ���Ǹ��ݸ��ھӵķ����������Լ��ķ���
    de_norm = de / norm(de, 2)
    %pne = proximityNetEdges(q,r_comm,r_lattice)
    
    subplotRows=1;%ceil(sqrt(updates)); ��������
    subplotCols=1;%floor(sqrt(updates));��������
    subplotCount=1;

    %control and state variables saved at points in time over evolution
    %ȷ��������״̬�������ݱ�����а�ʱ����
    u_history = zeros([round(u_steps), N, m]);
    uGradient_history = zeros([round(u_steps), N, m]);
    uConsensus_history = zeros([round(u_steps), N, m]);
    uGamma_history = zeros([round(u_steps), N, m]);
    uNew_history = zeros([round(u_steps), N, m]);
    q_history = zeros([round(steps), N, m]);
    e_history = zeros([round(steps), N, m]);
    for ai = 1 : numLyap
        v_history = zeros([ai, round(steps), 1, 1]); %R^(N*m) -> R
        vdot_history = zeros([ai, round(steps), 1, 1]);
    end
    alp_history = zeros([round(steps), N, m]);
    p_history = zeros([round(steps), N, m]);
    qr_history = zeros([round(steps), N, m]);
    pr_history = zeros([round(steps), N, m]);
    de_history = zeros([round(steps), N, m]);
    de_norm_history = zeros([round(steps), N, m]);
    nodeType_history = zeros([round(steps), N, m]);
    
    %uPeriod = (1:N)'.*Tc %different update periods for all particles
    uPeriod = ones(N,1)*Tc %same update period for all particles ���нڵ�ĸ���������ͬ
    %uPeriod = rand(N,1)*Tc %random update period for all particles (doesn't work as no particle will ever get update time)
    %uPeriod(1) = Tc*5; %make one node update its control slowly
    uOffset = zeros(N,1)

    if delay ~= 0
        %uOffset = delay_max + (delay_min - delay_max).*rand(N, 1) %add arbitrary delay to each control update
        tadd = tcyc / tdiv;
        for i=1:N
            to=round(rand(1,1)*tdiv);
            for j=1:to
                uOffset(i) = uOffset(i) + tadd;
            end
        end
        
        for i=1:N
            if uOffset(i) <= 0
                uOffset(i) = Tc
            end
        end
        
        uOffset
    end

    switches = 0; %initialize to 0 (before any goal updates occur) ��ʼ��Ϊ0�����κ�Ŀ����·���֮ǰ��
	
	t1=clock;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %system evolution ϵͳ�ݻ�
    for t=0:tcyc:tmax-tcyc        
        t_i=round(t/tcyc)+1;
        
        if terminate >= terminate_rounds
            tmax = t;
            u_steps=round(((tmax-tcyc)/tcyc))+1;
            steps=tmax/(tcyc/tdiv);
            
            %resize all vectors �������������Ĵ�С
            u_history = u_history(1:round(u_steps), 1:N, 1:m);
            uGradient_history = uGradient_history(1:round(u_steps), 1:N, 1:m);
            uConsensus_history = uConsensus_history(1:round(u_steps), 1:N, 1:m);
            uGamma_history = uGamma_history(1:round(u_steps), 1:N, 1:m);
            uNew_history = uNew_history(1:round(u_steps), 1:N, 1:m);
            q_history = q_history(1:round(steps), 1:N, 1:m);
            e_history = e_history(1:round(steps), 1:N, 1:m);
            v_history = v_history(1:ai, 1:round(steps), 1, 1); %R^(N*m) -> R
            vdot_history = vdot_history(1:ai, 1:round(steps), 1, 1);
            alp_history = alp_history(1:round(steps), 1:N, 1:m);
            p_history = p_history(1:round(steps), 1:N, 1:1:m);
            qr_history = qr_history(1:round(steps), 1:N, 1:m);
            pr_history = pr_history(1:round(steps), 1:N, 1:m);
            de_history = de_history(1:round(steps), 1:N, 1:m);
            de_norm_history = de_norm_history(1:round(steps), 1:N, 1:m);
            nodeType_history = nodeType_history(1:round(steps), 1:N, 1:m);
            
            break;
        end
        
%         if delay == 1 && t < Tc
%             continue;
%         end

        %update goals after some time
        %TODO: change to make new goals after reaching current goal (allows
        %      for arbitrary length system evolution that makes sense)
%         if t > tswitch && switches == 0
%             %set a new goal
%             qd = qd.^2 + ones(N, m)*100;
%             pd = pd.^2 + ones(N, m)*10;
%             qr = qd
%             pr = pd
%             switches = switches + 1;
%         end
%         
%         if t > (tswitch*3) && switches == 1
%             %set a new goal
%             qd = qd*2 + ones(N, m)*10;
%             pd = pd*2 + ones(N, m);
%             qr = qd
%             pr = pd
%             switches = switches + 1;
%         end
        %if t_i==1 || mod(t_i+1, u_steps / updates) == 0
            %we will call the below plotting loop every some odd iterations of the
            %system evolution to see how it's doing
            if m == 1 || m == 2 || m == 3
                %figure;
                %hold on;
            end

            if m == 1
%                 isSafety = zeros(N,1);
%                 isLattice = zeros(N,1);
%                 isComm = zeros(N,1);
%                 isElse = zeros(N,1);
%                 qSafety = zeros(N,1);
%                 qLattice = zeros(N,1);
%                 qComm = zeros(N,1);
%                 qElse = zeros(N,1);
% 
%                 %locate nodes satisfying different radius constraints
%                 %(communication, lattice, and safety) and plot in various
%                 %colors so we can more easily see system evolution
%                 %TODO: would be nice to have a bubble plot with radius of
%                 %      circles the size of the safety region (and also
%                 %      additionally interaction region if different
%                 %      radius), but Matlab's bubble plotting seems rather
%                 %      limited as the radius appears to be a relative size,
%                 %      not an actual point value
%                 iSafety=0;
%                 iLattice=0;
%                 iComm=0;
%                 iElse=0;
%                 for i=1:N
%                     done = 0;
%                     bad = 0;
%                     %search over already bad nodes and don't add again
%                     for j=1:N
%                         if i == isSafety(j) || i == isLattice(j) || i == isComm(j) || i == isElse(j)
%                             done = 1;
%                             break;
%                         end
%                     end
%                     
%                     if done == 1
%                         continue; %already added this as bad
%                     end
%                     
%                     for j=1:N
%                         if i == isSafety(j) && (i ~= j)
%                             bad = 1;
%                             break;
%                         elseif (norm(q(i,1) - q(j,1), 2) <= r_safety) && (i ~= j)
%                             %this needs to occur before other as anything
%                             %that satisfies safety would satisfy lattice
%                             %and comm
%                             qSafety(iSafety + 1) = q(i,:);
%                             isSafety(iSafety + 1) = i; %save indexes
%                             iSafety = iSafety + 1;
%                             bad = 1;
%                         elseif (norm(q(i,1) - q(j,1) - r_lattice, 2) <= delta) && (i ~= j)
%                             %TODO: change <= r_lattice to |qi - qj - r_lattice| <= delta
%                             %      to allow for quasi-lattices
%                             qLattice(iLattice + 1) = q(i,:);
%                             isLattice(iLattice + 1) = i; %save indexes
%                             iLattice = iLattice + 1;
%                             bad = 1;
%                         elseif (norm(q(i,1) - q(j,1), 2) <= r_comm) && (i ~= j)
%                             qComm(iComm + 1) = q(i,:);
%                             isComm(iComm + 1) = i; %save indexes
%                             iComm = iComm + 1;
%                             bad = 1;
%                         end
%                     end
%                     
%                     if bad == 0
%                         %if wasn't bad, add to good
%                         qElse(iElse + 1) = q(i,:);
%                         iElse = iElse + 1;
%                     end
%                 end
%                 qElse = qElse(1:iElse); %shrink
%                 qComm = qComm(1:iComm); %shrink
%                 qLattice = qLattice(1:iLattice); %shrink
%                 qSafety = qSafety(1:iSafety); %shrink
%                 qElse
%                 qComm
%                 qLattice
%                 qSafety
%                 scatter(qElse(:,1),zeros(iElse,1),'k');
%                 scatter(qComm(:,1),zeros(iComm,1),r_comm,'b');
%                 scatter(qLattice(:,1),zeros(iLattice,1),r_lattice,'g');
%                 scatter(qSafety(:,1),zeros(iSafety,1),r_safety,'r');
%                 %subplot(subplotRows,subplotCols,subplotCount), scatter(q(:,1),zeros(N,1),'b'); 
%                 scatter(qr(:,1),zeros(N,1),'g'); %plot goal
                %subplot(subplotRows,subplotCols,subplotCount), scatter(q(:,1),zeros(N,1),'b');
                scatter(q(:,1),zeros(N,1),'g');   %����ɢ��ͼ
                quiver(q(:,1),zeros(N,1),p(:,1),zeros(N,1),'g');  %���Ƴ��ڵ��ʸ����ͷ
                %scatter(qr(:,1),zeros(N,1),'r'); %plot goal
            elseif m == 2
                quiver(q(:,1),q(:,2),p(:,1),p(:,2),'k');
				hold on;
                subplot(subplotRows,subplotCols,subplotCount), scatter(q(:,1),q(:,2),'k');
				hold on;
				
                quiver(qr(:,1),qr(:,2),pr(:,1),pr(:,2),'r');
				hold on;
                subplot(subplotRows,subplotCols,subplotCount),scatter(qr(:,1),qr(:,2),'r');		
				hold on;				
				
				for i=1:size(Ms,2)
				Msx=-R_k(1,i):0.01:R_k(1,i);
				Msy1=sqrt(R_k(1,i)^2-Msx.^2);
				Msy2=-Msy1;
				patch([Msx+y_k(i,1) Msx((2*R_k(1,i)/0.01+1):-1:1)+y_k(i,1)],[Msy1+y_k(i,2) Msy2((2*R_k(1,i)/0.01+1):-1:1)+y_k(i,2)],'r')
				end
				
				hold on;
				
				xlabel('x(λ��)');
				ylabel('y(λ��)');
                %out=[[qd(:,1) (qd(:,1)+pd(:,1))] [qd(:,2) (qd(:,2)+pd(:,2))]];
                %subplot(subplotRows,subplotCols,subplotCount), plot([qd(:,1) (qd(:,1)+pd(:,1))],[qd(:,2) (qd(:,2)+pd(:,2))],'g')
                %subplot(subplotRows,subplotCols,subplotCount), plot([qd(:,1) (qd(:,1)+pd(:,1))],[qd(:,2) (qd(:,2)+pd(:,2))],'g')
                %subplotCount = subplotCount + 1;
            elseif m == 3
                quiver3(q(:,1),q(:,2),q(:,3),p(:,1),p(:,2),p(:,3),'g');
                subplot(subplotRows,subplotCols,subplotCount), scatter3(q(:,1),q(:,2),q(:,3),'g');
                quiver3(qr(:,1),qr(:,2),qr(:,3),pr(:,1),pr(:,2),pr(:,3),'r');
                subplot(subplotRows,subplotCols,subplotCount), scatter3(qr(:,1),qr(:,2),qr(:,3),'r');
                %subplotCount = subplotCount + 1;
            end

            %generate neighbors for all nodes and plot
            %TODO: have this simply create a data structure and then plot that
            %      What will that data structure look like?  Rather complicated
            %      multi-dimensional object without consistent number of elements
            %TODO: move to function
			suc_1 = 0;
            for i=1:N
                neighbors_i = neighborsSpatialLattice(i, q(i,:), q, r_comm, r_lattice, delta); %exclude self here if desired q_js: cat(1,q(1:i,:),q(i+1:size(q,1),:))
                js = neighborsSpatial(i, q(i,:), q, r_comm, r_lattice);%�˺���Ӧ���������ɻ��ڽڵ��ھӹ�ϵ�ľ���
				if ((size(js,1) == size(neighbors_i,1)) && (isempty(js) ~= 1))
					suc_1 = 1;
				end
				%spatial_neighbors(:,:,i) = neighbors_i;

                %TODO: speed this up by removing the for loop and doing
                %everything via index operations after generating the neighbors
                for j=1:size(neighbors_i)   %���ƽڵ���ھӹ�ϵ
                    %prune data
                    %if j > i
                    %    continue;
                    %end
                    
                    if m == 1
                        plot([q(i,1) q(neighbors_i(j),1)], [0 0]);
                    elseif m == 2
                        plot([q(i,1) q(neighbors_i(j),1)], [q(i,2) q(neighbors_i(j),2)]);
						hold on;
                    elseif m == 3
                        plot3([q(i,1) q(neighbors_i(j),1)], [q(i,2) q(neighbors_i(j),2)], [q(i,3) q(neighbors_i(j),3)]);
                    end
                end
            end

			
			drawnow;
			pause(0.0);
			hold off;
			
            %spatial_neighbors
        %end

        if tdiv == 1
            until = (t_i-1)*tdiv+1;
        else
            until = tdiv+(t_i-1)*tdiv+1;
        end

        for t_j=(t_i-1)*tdiv+1 : 1 : until
            if terminate >= terminate_rounds
                break;
            end
            tt=t_j*(tcyc/tdiv);
            %tcyc
            %t_j
            %tdiv
            %tt 
   

   
            %store all state variables over time ��ʱ��洢����״̬����
            q_history(t_j,:,:) = q(:,:);
            p_history(t_j,:,:) = p(:,:);
            qr_history(t_j,:,:) = qr(:,:);
            pr_history(t_j,:,:) = pr(:,:);
            de_history(t_j,:,:) = de(:,:);
            de_norm_history(t_j,:,:) = de_norm(:,:);
            nodeType_history(t_j,:,:) = nodeType(:,:);

            %compute control (based on state vector, possibly delayed, etc)
            % ������ƣ�����״̬�����������ӳٵȣ�
            for i=1:N
                if (mod(tt, (uPeriod(i) + uOffset(i))) == 0) % || t_j == 1 %uncomment to let start at t=0 instead of t=Tc ��t��0��ʼ�����Ǵ�Tc��ʼ
                    %tt
                    %u_i = u_i^\alpha + u_i^\gamma
                    %n_ij = ((q_j - q_i ) / (sqrt(1 + epsilon * norm(q_j - q_i, 2))^2));

                    %rho_h(z) = 1                                    if z \in [0,h)
                    %           1/2 * (1 + cos(pi * (z - h)/1 -h))   if z \in [h,1]
                    %           0                                    else
                    %for h \in (0,1)

                    %a_ij(q) = rho_h( sig_norm ( q_j - q_i ) / r_comm_sig )
                    %and a_ii(q) = 0 for all i, q
                    %a_ij(q) \in [0, 1]
                    % take h =1 (doesn't this violate set definition?

                    %sig_norm(z) = (1 / epsilon) * (sqrt(1 + epsilon * (norm(z,2))^2)-1)

                    %u_i = sumNghbs(\phi_a(sig_norm(q_j-q_i)) * n_ij) + 
                    %      sumNghbs(a_ij(q) * (p_j - p_i))

                    %store all controls over time ����ʱ������ƴ洢���п�������
                    u_history(t_i,:,:) = u(:,:);
                    uGradient_history(t_i,:,:) = uGradient(:,:);
                    uConsensus_history(t_i,:,:) = uConsensus(:,:);
					uBetaGradient_history(t_i,:,:) = uBetaGradient(:,:);
					uBetaConsensus_history(t_i,:,:) = uBetaConsensus(:,:);
                    uGamma_history(t_i,:,:) = uGamma(:,:);
                    uNew_history(t_i,:,:) = uNew(:,:);

                    %reinitialze this nodes controls (not dependent upon past control value)  ���³�ʼ���˽ڵ�ؼ�������������ǰ�Ŀؼ�ֵ��
                    if framework ~= 2
                        u(i,:) = zeros(1,m);
                    else
                        u(i,:) = q(i,:);
                    end
                    uGradient(i,:) = zeros(1,m);
                    uConsensus(i,:) = zeros(1,m);
                    uBetaGradient(i,:) = zeros(1,m);
                    uBetaConsensus(i,:) = zeros(1,m);
                    uGamma(i,:) = zeros(1,m);
                    uNew(i,:) = zeros(1,m);
                    
                    %delayed state messages  �ӳ�״̬��Ϣ
                    if delay == 0
                        q_delay = q;
                        p_delay = p;
                        u_delay = u;
                    else
                        if framework == 0
                            q_delay_tmp = q_history(round(t_j - (uPeriod(i) + uOffset(i)*tdiv)/Tc + 1),:,:);
                            p_delay_tmp = p_history(round(t_j - (uPeriod(i) + uOffset(i)*tdiv)/Tc + 1),:,:);
                            %u_delay_tmp = u_history(t_i,:,:);% add by ssl 
                        end

                        if m == 1
                            q_delay(1:N,:) = q_delay_tmp';
                            p_delay(1:N,:) = p_delay_tmp';
                            u_delay(1:N,:) = u_delay_tmp';
                        else
                            q_delay(1:N,:) = q_delay_tmp(:,1:N,:);
                            p_delay(1:N,:) = p_delay_tmp(:,1:N,:);
                            u_delay(1:N,:) = u_delay_tmp(:,1:N,:);
                        end
                    end

				
						%betas = 0;
						
                    if framework == 0 %olfati-saber control
                        js = neighborsSpatial(i, q(i,:), q, r_comm, r_lattice);   %�˺���Ӧ������Ѱ���ھ�֮���������޶������ĵ�
                        betas = neighborsSpatialObstacle(i, q(i,:), y_k, r_comm_prime, r_lattice_prime,R_k);%�˺���ҲӦ������Ѱ���ھ�֮���������޶������ĵ�
                        
                        mu = zeros(1,size(betas,1));
                        qhat_ik = zeros(size(betas,1),m);
                        phat_ik = zeros(size(betas,1),m);
                        %js = neighborsSpatialLattice(i, q(i,:), q, r_comm, r_lattice, delta);
                        %if size(js,1) > -1
                            for j=1:size(js,1)
                                %TODO: verify equations and all functions
                                %u(i,:) = u(i,:) + phi_a(sig_norm ( q(j,:) - q(i,:), epsilon ), r_comm_sig, r_lattice_sig, ha, a, b) * (((q(j,:) - q(i,:)) ) / (sqrt(1 + epsilon * ((norm(q(j,:) - q(i,:), 2))^2))));
                                %u(i,:) = u(i,:) + (a_ij(q(i,:), q(j,:), r_comm_sig, ha,epsilon) * ((p(j,:) - p(i,:))));
                                %old: uGradient(i,:) = uGradient(i,:) + phi_a(sig_norm ( q(js(j),:) - q(i,:), epsilon ), r_comm_sig, r_lattice_sig, ha, a, b) * n_ij(q(i,:), q(js(j),:), epsilon);
                                %old: uConsensus(i,:) = uConsensus(i,:) + (a_ij(q(i,:), q(js(j),:), r_comm_sig, ha, epsilon) * ((p(js(j),:) - p(i,:))));
                                uGradient(i,:) = uGradient(i,:) + phi_a(sig_norm ( q_delay(js(j),:) - q_delay(i,:), epsilon ), r_comm_sig, r_lattice_sig, ha, a, b) * n_ij(q_delay(i,:), q_delay(js(j),:), epsilon);
								uConsensus(i,:) = uConsensus(i,:) + (a_ij(q_delay(i,:), q_delay(js(j),:), r_comm_sig, ha, epsilon) * ((p_delay(js(j),:) - p_delay(i,:))));
                            end
                            
                            dq=zeros(N,size(betas,1),m);
                            dr=zeros(N,size(betas,1),m);
							unit_dr = zeros(N,m);
							unit_k1 = zeros(N,m);
							unit_k2 = zeros(N,m);
                         %obstacles
						 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
						 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
							%������ϰ�����������ڵ��Ƿ��о���
							%�ж��Ƿ��γɾ�������׼��1.�жϾ����Ƿ����� 2.�ж��ٶȵķ����Ƿ���ͬ
							%if betas ~= 0;
							%	neighbors_i = 0;
							%	neighbors_i = neighborsSpatialLattice(i, q(i,:), q, r_comm, r_lattice, delta);
							%end
							
                            for k=1:size(betas,1)
								
								%����q��obstacles֮��ļн�
								dq(i,k,:) = y_k(betas(k),:)-q_delay(i,:);%q->obstacles ����
								dq_dis = sqrt(dq(i,k,1)^2 + dq(i,k,2)^2);%q->obstacles ����
								sita_Rqp = acosd((dq(i,k,1)*p_delay(i,1)+dq(i,k,2)*p_delay(i,2))/((sqrt(dq(i,k,1)^2+dq(i,k,2)^2))*(sqrt(p_delay(i,1)^2+p_delay(i,2)^2))));%q��dq�н�
								sita_Rqs = asind((R_k(1,betas(k))+r_safety)/dq_dis);%���������߼н�
								
                                %if(flocking���γɣ�����r���� )
								%if neighbors_i ~= 0%%�Ѿ�flocking
								
									%û�г����ϰ���---ʲô������
								
									%�г����ϰ���--ת�����߷�����
									%if(sita_Rqp < sita_Rqs)
										
										
									

								
								%elseif( flockingδ�γ�,����r)
								%else 			%%��δflocking
									
									
																	
									dr(i,k,:) = qr(i,:)-q_delay(i,:);%q->r ����
									sita_Rqr = acosd((dr(i,k,1)*dq(i,k,1) + dr(i,k,2)*dq(i,k,2))/(sqrt(dr(i,k,1)^2 + dr(i,k,2)^2 )*sqrt(dq(i,k,1)^2 + dq(i,k,2)^2 )));
									
									%if(sita_Rqp > sita_Rqs)
									%û�г����ϰ���	r������ ֻ���ų��� ���ٶ�һֱ��
										%obstacles_flag = 1;
										%mu(1,k) = R_k(1,betas(k)) / norm(q_delay(i,:) - y_k(betas(k),:), 2);
										%a_k = (q_delay(i,:) - y_k(betas(k),:)) / norm(q_delay(i,:) - y_k(betas(k),:), 2);
										%P = eye(m) - a_k'* a_k;
										%qhat_ik(k,:) = mu(1,k) * q_delay(i,:) + (1 - mu(1,k)) * y_k(betas(k),:);
										%phat_ik(k,:) = mu(1,k) * P * p_delay(i,:)';
							
										%uBetaGradient(i,:) = uBetaGradient(i,:) + phi_b(sig_norm ( qhat_ik(k,:) - q_delay(i,:), epsilon ), r_comm_prime, hb) * n_ij(q_delay(i,:), qhat_ik(k,:), epsilon);
										%uBetaConsensus(i,:) = uBetaConsensus(i,:) + (a_ij(q_delay(i,:), qhat_ik(k,:), r_comm_prime, hb, epsilon) * ((phat_ik(k,:) - p_delay(i,:))));
																
									
									%if((sita_Rqp < sita_Rqs) && ((sita_Rqr > sita_Rqs) || (sita_Rqr ==sita_Rqs)))
									%�г����ϰ���	r������ ֱ�ӵ�������r
									%	unit_dr(i,:) = dr(i,k,:)/sqrt(dr(i,k,1)^2 + dr(i,k,2)^2);
									%	p(i,:)=unit_dr(i,:)*sqrt(p_delay(i,1)^2 + p_delay(i,2)^2);
									%	obstacles_flag = 1;
																										
									if(sita_Rqp < sita_Rqs) %&& (sita_Rqr < sita_Rqs))
									%�г����ϰ��� 	r������(��ʱ��Ҫ��r�����ߵ�������Ҳ�����ж�)
										
										coeff_a = (y_k(betas(k),1) - q_delay(i,1))^2 - (R_k(1,betas(k))+r_safety)^2;
										coeff_b = 2*(y_k(betas(k),1) - q_delay(i,1))*( q_delay(i,2) - y_k(betas(k),2));
										coeff_c = (q_delay(i,2) - y_k(betas(k),2))^2 - (R_k(1,betas(k))+r_safety)^2;
																																											
										k1 = (-coeff_b + sqrt(coeff_b^2 - 4*coeff_a*coeff_c))/(2*coeff_a);
										k2 = (-coeff_b - sqrt(coeff_b^2 - 4*coeff_a*coeff_c))/(2*coeff_a);
										
										unit_k1(i,1) = 1/sqrt(1^2 + k1^2);
										unit_k1(i,2) = k1/sqrt(1^2 + k1^2);
										unit_k2(i,1) = 1/sqrt(1^2 + k2^2);
										unit_k2(i,2) = k2/sqrt(1^2 + k2^2);
										
										%sita_Rrs1 = acosd((dr(i,k,1)*1 + dr(i,k,2)*k1)/(sqrt(dr(i,k,1)^2 + dr(i,k,2)^2)*(sqrt(1^2+k1^2))));%r��s1�н�
										%sita_Rrs2 = acosd((dr(i,k,1)*1 + dr(i,k,2)*k2)/(sqrt(dr(i,k,1)^2 + dr(i,k,2)^2)*(sqrt(1^2+k2^2))));%r��s2�н�
										sita_Rps1 = acosd((p_delay(i,1)*1 + p_delay(i,2)*k1)/(sqrt(p_delay(i,1)^2 + p_delay(i,2)^2)*(sqrt(1^2+k1^2))));%p��s1�н�
										sita_Rps2 = acosd((p_delay(i,1)*1 + p_delay(i,2)*k2)/(sqrt(p_delay(i,1)^2 + p_delay(i,2)^2)*(sqrt(1^2+k2^2))));%p��s2�н�
										
										%if(sita_Rrs1 < sita_Rrs2)
										if(sita_Rps1 < sita_Rps2)
											p(i,:)=unit_k1(i,:)*sqrt(p_delay(i,1)^2 + p_delay(i,2)^2 );
										else
											p(i,:)=unit_k2(i,:)*sqrt(p_delay(i,1)^2 + p_delay(i,2)^2 );
										end
										obstacles_flag = 1;
																									
									end
								%end	
							end
            %             else
            %                 %no neighbors yet: have to compute something
            %                 %TODO: fix, not right (always 0 obviously)
            %                 u(i,:) = u(i,:) + phi_a(sig_norm ( q(i,:) - q(i,:), epsilon ), r_comm_sig, r_lattice_sig, ha, a, b) * (((q(i,:) - q(i,:)) ) / (sqrt(1 + epsilon * norm(q(i,:) - q(i,:), 2))^2));
            %                 u(i,:) = u(i,:) + (a_ij(q(i,:), q(i,:), r_comm_sig, ha, epsilon) * ((p(i,:) - p(i,:))));
            %             end

                        %add gamma goal term
                        %u(i,:) = u(i,:) - c1*(q(i,:) - qr(i,:)) - c2*(p(i,:) - pr(i,:));
                        %old: uGamma(i,:) = -c1*(q(i,:) - qr(i,:)) - c2*(p(i,:) - pr(i,:));

                        %uGamma(i,:) = -c1gamma*sigma_1_r((q_delay(i,:) - qr(i,:))) - c2gamma*(p_delay(i,:) - pr(i,:));
                        uGamma(i,:) = -c1gamma*((q_delay(i,:) - qr(i,:))) - c2gamma*(p_delay(i,:) - pr(i,:));
																		
						%uBeta(1,:) = uBetaGradient(i,:) + uBetaConsensus(i,:);									
                        %if(uBeta(1,1) ~= 0 && uBeta(1,2) ~= 0)
						%uGamma(i,:) = zeros(1,m);
                        %end
                        %sum all forces
						if(obstacles_flag == 1)
						u(i,1) = 0;
						u(i,2) = 0;
						obstacles_flag = 0;
						else
                        u(i,:) = uGradient(i,:) + uConsensus(i,:) + uGamma(i,:);%+ c1beta*uBetaGradient(i,:) + c2beta*uBetaConsensus(i,:);
						end
					   %u(i,:) = uGradient(i ,:) + uConsensus(i,:) + uGamma(i,:);
					end
                end
            end
            
            %run system evolution
            
            %saturate the controls (no effect until out of neighbors loop
            %above, so might as well be efficient and do it once for
            %everything) ����ϵͳ�ݻ�ʹ�ؼ������������ѭ���������ھӣ����򲻻�����κ�Ч������������Ǹ�Ч��ִ��һ�����в�����
            if constrain ~= 0
                u = sign(u).*(min(abs(u),a_max));
                
                %saturate the velocity ʹ�ٶȱ���
                %sign(p)
                %(min(abs(p),v_max))
                p = sign(p).*(min(abs(p),v_max));
            end

            %state space form
            %q'=p;     => [q'; p']=[0 1; 0 0]*[q; p] + [0;1]*[u]
            %p'=u;
            
            %solution is:
            %  expm(A*(t-t0))*x0+int(expm(A*(t-t0))*B*u,tau,t0,t)
            %for
            %  syms q p q0 p0 tau t t0 u
            %  x = [q;p]
            %  x0 = [q0; p0]
            %  A = [0 1; 0 0]
            %  B = [0; 1]
            %which expands to
            %  [x]=[q;= [q0 + p0*(t - t0) + u*(t - t0)^2;
            %       p]   p0 + u*(t - t0)]
			
			
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%all the agent have the same velocity  ���еĽڵ㶼����ͬ���ٶ�
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			con_flag = 0;
			flocking_suc_2 = 0;
			for p_index_w = 1:N-1
				for p_index_n = (p_index_w+1):N
					p_error_1 = p(p_index_w,1) - p(p_index_n,1);
					p_error_2 = p(p_index_w,2) - p(p_index_n,2);
					if ((abs(p_error_1) > 0.5 ) && (abs(p_error_2) >0.5 ))
						con_flag = 1;
						break;
					end
				end
				if con_flag == 1
					break;
				end
			end
			
			if ((p_index_w == N-1) && (p_index_n == N))
				flocking_suc_2 = 1;
				flocking_suc_2
				flocking_suc_2_cnt = flocking_suc_2_cnt+1;
				
			end
			
			suc_2 = 0;
			if flocking_suc_2_cnt > 10
				suc_2 = 1;
				break;
			end
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			

            if system_type == 0
                %q = q + p.*(tcyc/tdiv)*0.1 + u.*((tcyc/tdiv)^2)*0.1;
				q = q + p.*(tcyc/tdiv);		
                p = p + u.*(tcyc/tdiv);
				

            elseif system_type == 1
                %no velocity, next position is directly computed
                q = u;
            elseif system_type == 2
                %
            elseif system_type == 3
                %ctrl123
                %adding dynamics to discrete version--move towards the compute control value
                %q = q + (tcyc/tdiv).*(u - q); %this just guarantees each node gets to u by next control cycle update
                %q = q + (tcyc/tdiv).*(u - q)*rand(1,1); %this seems to work
                %q = q + max( (tcyc/tdiv).*(u - q), (tcyc/tdiv).*(u - q)*rand(1,1));
                %q = q + (tcyc/tdiv).*(u - q)*rand(1,1)./alp;
                q = u;
            elseif system_type == 4
                %q = q + (tcyc/tdiv).*(u - q).*min(max(0.001, rand(1,1)),0.999); %any number of velocities, and "maybe" reach goal
                %q = q + (tcyc/tdiv).* quantize( ((u - q).*min(max(0.001, rand(1,1)),0.999)) , quant_mode, quantizer_precision);
                %q = q + (tcyc/tdiv).*quantize( ((u - q)) , quant_mode, quantizer_precision);
                %q = u;
                %q = q + (tcyc/tdiv).*(u - q)*rand(1,1);
                %v_c = 5;
                %q = max(u, q + (u - q)/norm(u - q, 2)*v_c); %only synchronus
                q=u;
                %q = q + (tcyc/tdiv).*(max(u, q + (u - q)/norm(u - q, 2)*v_c) - q); %with asynchrony
                
                
                %v_c = ones(N,1)*25;
                %v_i = min(v_c, abs(u - q)./(tcyc/tdiv));
                %q = q + (tcyc/tdiv).*(sign(u - q).*v_i); %with asynchrony
                %return
            end

            if constrain ~= 0
                p = sign(p).*(min(abs(p),v_max));
                u = sign(u).*(min(abs(u),a_max));
            end
            
            de = deviationEnergy(framework, q, q_goal, r_comm, r_lattice, delta);
            de_norm = de / norm(de,2);

            %gamma agent
            frv = fr(qr, pr);
            if constrain ~= 0
                frvs = sign(frv).*(min(abs(frv),a_max));
            else
                frvs=frv;
            end
            
            if system_type == 0
                qr=qr + pr.*(tcyc/tdiv) + frvs.*((tcyc/tdiv)^2);
                pr=pr + frvs.*(tcyc/tdiv);
            elseif system_type == 1
                qr = frvs;
            end
            
            if constrain ~= 0
                pr = sign(pr).*(min(abs(pr),v_max));
            end
            
            %check for safety violations
%             for xyz=1:N
%                 N_safety = neighborsSpatial(xyz, q(xyz), q, r_safety, r_safety);
%                 if (size(N_safety) > 0)
%                     %'Bad safety'
%                     %N_safety
%                 end
%             end
            
            %beta agent
            %mu = R_k / norm(q_i - y_k, 2);
            %a_k = (q_delay - y_k) / norm(q_delay - y_k, 2);
            %P = I - a_k * a_k';
            %qhat_ik = mu * q_i + (1 - mu) * y_k;
            %phat_ik  = mu * P * p_i;
        end
		
		if ((suc_2 == 1) && (suc_1 == 1))
			break;
		end
    end
    
	%toc;%%%%deadtime
    t2 = etime(clock,t1)
	
    out = u_history;

    %plot controls over time
    if plotControls >= 1
        if plotControls >= 3
            %plot distance of each node so we can see how their lattice evolves
            figure;
            hold on;
            if m == 1
                plot(time_traj(1:size(q_history(:,1,1))),q_history(:,N,1),'k');
                plot(time_traj(1:size(q_history(:,N,1))),q_history(:,1,1),'g');
                for i=2:N-1
                    if mod(i,2)==0
                        %plot(time_traj(1:size(q_history(:,i,1))),q_history(:,i,1),'c');
                        plot(time_traj(1:size(q_history(:,i,1))),q_history(:,i,1),'r');
                        %plot(time_traj(1:size(q_history(:,i,1))),q_history(:,i,1),'c','LineWidth',r_comm);
                        %plot(time_traj(1:size(q_history(:,i,1))),q_history(:,i,1),'r','LineWidth',r_safety);
                        %plot(time_traj(1:size(q_history(:,i,1))),q_history(:,i,1)+(r_safety/2),'k--');
                        %plot(time_traj(1:size(q_history(:,i,1))),q_history(:,i,1)-(r_safety/2),'k--');
                        %plot(time_traj(1:size(q_history(:,i,1))),q_history(:,i,1)+(r_comm/2),'c');
                        %plot(time_traj(1:size(q_history(:,i,1))),q_history(:,i,1)-(r_comm/2),'c');
                    else
                        %plot(time_traj(1:size(q_history(:,i,1))),q_history(:,i,1),'m');
                        plot(time_traj(1:size(q_history(:,i,1))),q_history(:,i,1),'b');
                        %plot(time_traj(1:size(q_history(:,i,1))),q_history(:,i,1),'m','LineWidth',r_comm);
                        %plot(time_traj(1:size(q_history(:,i,1))),q_history(:,i,1),'b','LineWidth',r_safety);
                        %plot(time_traj(1:size(q_history(:,i,1))),q_history(:,i,1)+(r_safety/2),'g--');
                        %plot(time_traj(1:size(q_history(:,i,1))),q_history(:,i,1)-(r_safety/2),'g--');
                        %plot(time_traj(1:size(q_history(:,i,1))),q_history(:,i,1)+(r_comm/2),'m');
                        %plot(time_traj(1:size(q_history(:,i,1))),q_history(:,i,1)-(r_comm/2),'m');
                    end
                end
                legend('q1');
                
                figure;
                hold on;
                beta_const0 = ones(size(p_history(:,1,1)))*(delta/(4*(N-1)));
                beta_const1 = ones(size(p_history(:,1,1)))*(delta/2);
                plot(time_traj(1:size(q_history(:,i,1))),beta_const0,'r:')
                plot(time_traj(1:size(q_history(:,i,1))),-beta_const0,'r:')
                plot(time_traj(1:size(q_history(:,i,1))),beta_const1,'k:')
                plot(time_traj(1:size(q_history(:,i,1))),-beta_const1,'k:')
                plot(time_traj(1:size(p_history(:,1,1))),p_history(:,N,1),'k');
                plot(time_traj(1:size(p_history(:,N,1))),p_history(:,1,1),'g');
                for i=2:N-1
                    if mod(i,2)==0
                        plot(time_traj(1:size(p_history(:,i,1))),p_history(:,i,1),'r');
                    else
                        plot(time_traj(1:size(p_history(:,i,1))),p_history(:,i,1),'b');
                    end
                end
                legend('delta/(4*(N-1))', '-delta/(4*(N-1))', 'delta/2', '-delta/2', 'p1', 'pN');
                
                figure;
                hold on;
                plot(time_traj(1:size(q_history(:,1,1))),de_history(:,1,1),'k');
                plot(time_traj(1:size(q_history(:,N,1))),de_history(:,N,1),'g');
                for i=2:N-1
                    if mod(i,2)==0
                        plot(time_traj(1:size(q_history(:,i,1))),de_history(:,i,1),'r');
                    else
                        plot(time_traj(1:size(q_history(:,i,1))),de_history(:,i,1),'b');
                    end
                end
                plot(time_traj(1:size(q_history(:,i,1))),de_norm_history(:,1),'k');
                legend('de1');
                
                figure;
                hold on;
                plot(time_traj(1:size(q_history(:,1,1))),e_history(:,1,1),'k'); %color separately
                if (N >= 2)
                    plot(time_traj(1:size(q_history(:,2,1))),e_history(:,2,1),'y');
                end
                if (N >= 3)
                    plot(time_traj(1:size(q_history(:,N,1))),e_history(:,N,1),'g');
                end
                for i=3:N-1
                    if mod(i,2)==0
                        plot(time_traj(1:size(q_history(:,i,1))),e_history(:,i,1),'r');
                    else
                        plot(time_traj(1:size(q_history(:,i,1))),e_history(:,i,1),'b');
                    end
                end
                
                colors = 'bgcmykbgcmyk';
                
                for a = 1 : numLyap
                    size(time_traj(1:size(q_history(:,i,1))))
                    size(v_history(a,:,1))
                    v(a)=plot(time_traj(1:size(q_history(:,i,1))),v_history(a,:,1),colors(a));
                    vd(a)=plot(time_traj(1:size(q_history(:,i,1))),vdot_history(a,:,1),strcat(colors(a),'.'));
                    %v2=plot(time_traj(1:size(q_history(:,i,1))),v2_history(:,1),'k');
                    %v2d=plot(time_traj(1:size(q_history(:,i,1))),v2dot_history(:,1),'k.');
                    %v3=plot(time_traj(1:size(q_history(:,i,1))),v3_history(:,1),'g');
                    %v3d=plot(time_traj(1:size(q_history(:,i,1))),v3dot_history(:,1),'g.');
                    max(vdot_history(a,:,:))
                    vlast(a) = inf;
                    ibad(a) = 1;
                    iequal(a) = 1;
                    vlegend(a,:) = strcat('v',int2str(a));
                    vdlegend(a,:) = strcat('vd',int2str(a));

                    for asdf = 1 : size(time_traj(1:size(q_history(:,i,1))))
                        if v_history(a,asdf,1) > vlast
                            %'Error: increasing Lyapunov function'
                            %vlast(a)
                            %v_history(a,asdf,1)
                            vbad(a,ibad(a),:) = [asdf - 2, v_history(a,asdf-1,1)]; %asdf - 2 since time is 0 indexed
                            ibad(a) = ibad(a) + 1;
                            vbad(a,ibad(a),:) = [asdf - 1, v_history(a,asdf,1)];
                            ibad(a) = ibad(a) + 1;
                        elseif v_history(a,asdf,1) == vlast
                            vequal(a,iequal(a),:) = [asdf - 2, v_history(a,asdf-1,1)]; %asdf - 2 since time is 0 indexed
                            iequal(a) = iequal(a) + 1;
                            vequal(a,iequal(a),:) = [asdf - 1, v_history(a,asdf-1,1)];
                            iequal(a) = iequal(a) + 1;
                        end
                        vlast(a) = v_history(a,asdf,1);
                    end
                end
                k_const_vsquaremul2 = ones(size(q_history(:,1,1)))*((N-1)*jumpError*2)^2; %delta
                k_const_vsquare = ones(size(q_history(:,1,1)))*((N-1)*jumpError)^2; %delta
                k_const_vsquarediv2 = ones(size(q_history(:,1,1)))*((N-1)*jumpError/2)^2; %delta
                k_const_vmul2 = ones(size(q_history(:,1,1)))*(N-1)*jumpError*2; %delta
                k_const_v = ones(size(q_history(:,1,1)))*(N-1)*jumpError; %delta/2
                k_const_vdiv2 = ones(size(q_history(:,1,1)))*(N-1)*jumpError/2; %delta/4
                plot(time_traj(1:size(q_history(:,i,1))),k_const_vsquaremul2,'g:')
                plot(time_traj(1:size(q_history(:,i,1))),k_const_vsquare,'k:')
                plot(time_traj(1:size(q_history(:,i,1))),k_const_vsquarediv2,'y:')
                plot(time_traj(1:size(q_history(:,i,1))),k_const_vmul2,'r:')
                plot(time_traj(1:size(q_history(:,i,1))),k_const_v,'m:')
                plot(time_traj(1:size(q_history(:,i,1))),k_const_vdiv2,'c:')
                %bar(updates_v(:,1), updates_v(:,2), 0.05);
                legend([v,vd], strvcat(vlegend, vdlegend));
                
                %do this second to get all bad points plotted on very top
                for a = 1 : numLyap
                    if ibad(a) > 1
                        plot(vbad(a,:,1), vbad(a,:,2), 'xr');
                    elseif iequal(a) > 1
                        plot(vequal(a,:,1), vequal(a,:,2), 'xm');
                    end
                end
                               
            elseif m == 2
                for i=1:N
                    if mod(i,2)==0
                        plot(time_traj,(q_history(:,i,1).^2 + q_history(:,i,2).^2).^(1/2),'r');
                    else
                        plot(time_traj,(q_history(:,i,1).^2 + q_history(:,i,2).^2).^(1/2),'b');
                    end
                    legend('q2');
                end
            end
        end

        if plotControls == 2 || plotControls >= 4
            for i=1:N
                figure;
                hold on;

                if m == 1
                    plot(time_ctrl,u_history(:,i,1),'b--');
                    %plot(time_ctrl,uGradient_history(:,i,1),'r--');
                    %plot(time_ctrl,uConsensus_history(:,i,1),'k--');
                    %plot(time_ctrl,uGamma_history(:,i,1),'g--');
                    plot(time_ctrl,uNew_history(:,i,1),'m--');
                    plot(time_traj(1:size(q_history(:,i,1))),q_history(:,i,1),'c-.');
                    plot(time_traj(1:size(p_history(:,i,1))),p_history(:,i,1),'g-.');
                    %plot(time_traj,q_history(:,i,1) - qr_history(i,1),'c-.');
                    %plot(time_traj,p_history(:,i,1) - pr_history(i,1),'m-.');
                    %plot(time_traj,de_history(:,i,1),'c');
                    %legend('u', 'uGradient', 'uConsensus', 'uGamma', 'q-qr', 'p-pr');
                    %legend('u', 'uGradient', 'uConsensus', 'uGamma', 'de');
                    legend('u', 'uNew', 'q', 'p', 'de');
                elseif m == 2
                    %plot(time_ctrl,u_history(:,i,1),'b--');
                    %plot(time_ctrl,u_history(:,i,2),'c--');
                    plot(time_ctrl,sqrt(u_history(:,i,1).^2 + u_history(:,i,2).^2),'b--');
                    plot(time_ctrl,sqrt(uGradient_history(:,i,1).^2 + uGradient_history(:,i,2).^2),'r--');
                    plot(time_ctrl,sqrt(uConsensus_history(:,i,1).^2 + uConsensus_history(:,i,2).^2),'k--');
                    plot(time_ctrl,sqrt(uGamma_history(:,i,1).^2 + uGamma_history(:,i,2).^2),'g--');
                    plot(time_ctrl,sqrt(p_history(:,i,1).^2 + p_history(:,i,2).^2),'k:');
                    %plot(time_traj,q_history(:,i,1) - qd(i,1),'r:');
                    %plot(time_traj,q_history(:,i,2) - qd(i,1),'m:');
                    %plot(time_traj,p_history(:,i,1) - pd(i,1),'k:');
                    %plot(time_traj,p_history(:,i,2) - pd(i,1),'b:');
                    legend('u', 'uGradient', 'uConsensus', 'uGamma','p');

                    if plotControls == 2
                        figure;
                        hold on;
                        plot3(time_ctrl,u_history(:,i,1),u_history(:,i,2),'b--');
                        plot3(time_ctrl,uGradient_history(:,i,1),uGradient_history(:,i,2),'r--');
                        plot3(time_ctrl,uConsensus_history(:,i,1),uConsensus_history(:,i,2),'k--');
                        plot3(time_ctrl,uGamma_history(:,i,1),uGamma_history(:,i,2),'g--');
                        %plot3(time_ctrl,q_history(:,i,1) - qr(i,1),q_history(:,i,2) - qr(i,2),'r:');
                        plot3(time_ctrl,p_history(:,i,1),p_history(:,i,2),'k:');
                        legend('u', 'uGradient', 'uConsensus', 'uGamma', 'p');%, 'q - qd'
                    end
                elseif m == 3
                    %use only norms here or we'll get too busy
                    plot(time_ctrl,sqrt(u_history(:,i,1).^2 + u_history(:,i,2).^2 + u_history(:,i,3).^2),'b--');
                    plot(time_ctrl,sqrt(uGradient_history(:,i,1).^2 + uGradient_history(:,i,2).^2 + uGradient_history(:,i,3).^2),'r--');
                    plot(time_ctrl,sqrt(uConsensus_history(:,i,1).^2 + uConsensus_history(:,i,2).^2 + uConsensus_history(:,i,3).^2),'k--');
                    plot(time_ctrl,sqrt(uGamma_history(:,i,1).^2 + uGamma_history(:,i,2).^2 + uGamma_history(:,i,3).^2),'g--');
                    legend('u', 'uGradient', 'uConsensus', 'uGamma');
                end
            end
        end
    end

    %average position and velocity for moving reference frame
    q
    p
    qd
    qr
    pd
    pr
    de
    qc=Ave(q)
    pc=Ave(p)
    %updates_v;
    %size(updates_v)
    %const_fact
    %min_const
    %max_const
    pretty(sym(q_history(1:10,:,:),'d')) %display values of position state
    pretty(sym(q_history(t_j - 10:t_j,:,:),'d'))
    goal
end


%Obstacle notes

%split rejoin setup
%q0: [-40, 80]^2
%p0: [0, 0]
%group objective, static gamma agent: 
%qd=[200,30]'
%pd=[5,0]'
%c1alpha < c1gamma < c1beta
%c2nu = 2 * sqrt(c1nu)  (for all beta, gamma, alpha constants)
%
%obstacles:

%Ms = [100 110 120 130 150 160; 20 60 40 -20 40 0; 10 4 2 5 5 3]

%squeezing manaeuver:
%n=150
%q0: [0, 120]^2
%p0: [0, 0]^2
%group objective: static gamma agent
%qd=[230, 60]'
%pd=[6, 0]'
%c1alpha < c1gamma < c1beta
%c2nu = 2 * sqrt(c1nu) (for all beta, gamma, alpha constants)

%obstacles:
%Ms = [150 150; 30 100; 25 25]

%Ms is defined as:
%The set of l spherical obstacles is specified as the
%(m + 1) by l matrix Ms where each column of Ms is the
%vector col(y_k, R_k) \in R^(m+1)

%radius Rk center at yk
%mu = R_k \ norm(q_i - y_k, 2)
%a_k = (q_i - y_k) \ norm(q_i - y_k, 2)
%P = I - a_k * a_k'
%qhat_ik = mu * q_i + (1 - mu) * y_k
%phat_ik  = mu * P * p_i
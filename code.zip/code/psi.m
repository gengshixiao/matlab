function [out] = psi(z)
    out = z^2;
end
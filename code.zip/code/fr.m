function [out] = fr(qr, pr)
    out = zeros(size(qr));
    %out = ones(size(qr));
end
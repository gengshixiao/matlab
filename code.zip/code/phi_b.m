function [out] = phi_b(z, d_pie_sig, h)
    out = rho_h(z / d_pie_sig, h) * (sigma_1(z - d_pie_sig)-1);
end
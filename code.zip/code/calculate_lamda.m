function [ p_flock ] = calculate_lamda(R_max,D_max,roh,nodes_number,t_epsilon,nodes_p)%

E_lamda_2 = 0;
E_lamda_2_square = 0;
p_sum = 0;
%nodes_number �ڵ���Ŀ ������6
%R_max	ͨ�Ű뾶�Ͻ�
%D_max	�ڵ�֮��������

if D_max > (R_max - roh) 
	Pr_1 = (R_max-roh)^2/(2*D_max*R_max);	%�ڽӾ���Ԫ��Ϊ1�ĸ���
else
	Pr_1 = (D_max*(2*R_max - D_max - 2*roh))/(2*D_max*R_max);
end
%Pr_1 = Pr_1^2;
Pr_0 = 1 - Pr_1;		%�ڽӾ���Ԫ��Ϊ0�ĸ���

nodes_list = 1:nodes_number-1;
element_num = sum(nodes_list);%�϶Խ�Ԫ�صĸ���

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%����ڶ�С����ֵ�ĸ���
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%����ÿ���ڽӾ���ĶȾ��������ֵ
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

A = zeros(nodes_number,nodes_number);

for index_dec = 1:(2^element_num - 1)
	index_bin = dec2bin(index_dec);
	size_bin = size(index_bin,2);
	index_bin_index = 1;
	finish_flag = 0;
	cnt_1 = 0;
	for i = 1: (nodes_number-1)
		for j = (i+1):nodes_number
			A(i,j) = str2num(index_bin(index_bin_index));
			A(j,i) = A(i,j);
			if index_bin(index_bin_index) == '1'
				cnt_1 = cnt_1 + 1;
			end
			if index_bin_index == size_bin
				finish_flag = 1;
				break;
			end
			index_bin_index = index_bin_index + 1;
			
		end
		if finish_flag == 1
			finish_flag = 0;
			break;
		end
	end
	D = zeros(nodes_number,nodes_number);
	for i = 1:nodes_number
		D(i,i) = sum(A(i,:));
	end
	
	L = D - A;
	
	[eigen_vector,eigen_value]=eig(L);
	eigen_value = diag(eigen_value);
	min_eigen_value = min(eigen_value);
	eigen_value(eigen_value == min_eigen_value) = [];
	lamda_2(index_dec) = min(eigen_value);
	Pr_lamda_2(index_dec) = Pr_1^cnt_1*Pr_0^(element_num - cnt_1);
	E_lamda_2 = E_lamda_2 + Pr_lamda_2(index_dec)*lamda_2(index_dec);
	p_sum =  p_sum + Pr_lamda_2(index_dec);
	E_lamda_2_square = E_lamda_2_square + Pr_lamda_2(index_dec)*(lamda_2(index_dec)^2);
	
end
	
	E_lamda_2 = E_lamda_2
	E_lamda_2_square = E_lamda_2_square;
	p_sum = p_sum + Pr_0^element_num;
	p_sum;
	nodes_p_ave_x = mean(nodes_p(:,1));
	nodes_p_ave_y = mean(nodes_p(:,2));
	delta_0_sum = 0;
	for index = 1:size(nodes_p,1)
		delta_0(index,1) = nodes_p(index,1) - nodes_p_ave_x;
		delta_0(index,2) = nodes_p(index,2) - nodes_p_ave_y;
		
		delta_0_pre_norm(index) = norm(delta_0(index,:));
		delta_0_sum = delta_0_sum + delta_0_pre_norm(index)^2;
		
	end
	
	delta_0_norm = sqrt(delta_0_sum);
	
	v_epsilon = t_epsilon*(E_lamda_2_square - E_lamda_2^2) / (2*E_lamda_2 - t_epsilon*E_lamda_2_square)
	k = (1/v_epsilon)*(roh*E_lamda_2/(sqrt(2)*delta_0_norm) - 1)^2;
	p_flock = 1 - 1/(1 + k)
	eroh = roh*E_lamda_2
	
	
	
	rate = delta_0_norm/(eroh/sqrt(2))
	













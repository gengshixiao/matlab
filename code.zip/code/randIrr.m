function [ out,matr,degree ] = randIrr(N)
con_flag = 0;
while con_flag == 0
A=zeros(N,N);
	for i=1:N
		for j=1:N
			seed=rand(1);
			if 	seed<=0.5
				A(i,j)=0;
				A(j,i)=A(i,j);
			else
				A(i,j)=1;
				A(j,i)=A(i,j);
			end
		end
	end
	
	connect_set = zeros(1,N);
	for i=1:N
		for j=(i+1):N
			if A(i,j) == 1
				
				if (i==1 && j==2)
				connect_set = union(connect_set,i);
				connect_set = union(connect_set,j);
				end
				D1 = intersect(i,connect_set);
				D2 = intersect(j,connect_set);
				if	(isempty(D1) == 0 || isempty(D2) == 0)
					connect_set = union(connect_set,i);
					connect_set = union(connect_set,j);
				end	
			end
		end
    end
    connect_set = nonzeros(connect_set)';
	if size(connect_set,2)==N
		con_flag = 1;
		D = zeros(1,N);
		for i=1:N;
			for j=1:N
				if A(i,j)==1
					D(1,i) = D(1,i) + 1;
				end
			end
		end
	else
		con_flag = 0;
    end
end
    
	out = con_flag;
	matr = A;
    degree = D;
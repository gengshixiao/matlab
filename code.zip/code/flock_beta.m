function [ out ] = flockbeta.(m)
%UNTITLED1 Summary of this function goes here
%  Detailed explanation goes here
x=0:10;
a1=[234.5,215.7,278.6,264.4,245.4,264.8,217.9,244.6,265.2,223.2];
a2=[289.8,279.6,302.4,295.7,290.4,287.9,286.7,297.6,279.6,288.0];
plot(x,a1);
hold on
plot(x,a2);



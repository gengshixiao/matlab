function [ out ] = SearchNeighborsNearest(Neighbors,q_i)
neighbors_temp = zeros(size(Neighbors,1),m);